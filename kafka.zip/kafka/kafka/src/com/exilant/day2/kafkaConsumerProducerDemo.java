package com.exilant.day2;

public class kafkaConsumerProducerDemo 
{
	
	public static void main(String [] args)
	{
		boolean isAsync = true;
		
		Producer producer = new Producer(KafkaProperties.TOPIC, isAsync);
		
		producer.start();
		
		Consumer consumer = new Consumer (KafkaProperties.TOPIC, false);
		
		consumer.start();
		
	}

}
