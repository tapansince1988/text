package com.exilant.day2;

import java.util.Arrays;
import java.util.List;

public class Testing {
	public static void main(String [] arg)
	{
		List<String> list = Arrays.asList("Hello", "how", "are", "you");
		
	}

}
